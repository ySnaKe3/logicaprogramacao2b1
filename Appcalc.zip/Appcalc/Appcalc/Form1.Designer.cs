﻿namespace Appcalc
{
    partial class Frm1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn0 = new System.Windows.Forms.Button();
            this.btnvirgula = new System.Windows.Forms.Button();
            this.btnigual = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btnmais = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btndividir = new System.Windows.Forms.Button();
            this.btnmutiplicacao = new System.Windows.Forms.Button();
            this.btnmenos = new System.Windows.Forms.Button();
            this.btnporcentagem = new System.Windows.Forms.Button();
            this.btnmaismenos = new System.Windows.Forms.Button();
            this.btnAC = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn0
            // 
            this.btn0.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn0.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn0.Location = new System.Drawing.Point(10, 226);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(75, 23);
            this.btn0.TabIndex = 0;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = false;
            this.btn0.Click += new System.EventHandler(this.btn0_Click);
            // 
            // btnvirgula
            // 
            this.btnvirgula.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnvirgula.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnvirgula.Location = new System.Drawing.Point(110, 226);
            this.btnvirgula.Name = "btnvirgula";
            this.btnvirgula.Size = new System.Drawing.Size(75, 23);
            this.btnvirgula.TabIndex = 1;
            this.btnvirgula.Text = ",";
            this.btnvirgula.UseVisualStyleBackColor = false;
            this.btnvirgula.Click += new System.EventHandler(this.btnvirgula_Click);
            // 
            // btnigual
            // 
            this.btnigual.BackColor = System.Drawing.Color.OrangeRed;
            this.btnigual.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnigual.Location = new System.Drawing.Point(213, 226);
            this.btnigual.Name = "btnigual";
            this.btnigual.Size = new System.Drawing.Size(75, 23);
            this.btnigual.TabIndex = 2;
            this.btnigual.Text = "=";
            this.btnigual.UseVisualStyleBackColor = false;
            this.btnigual.Click += new System.EventHandler(this.btnigual_Click);
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn1.Location = new System.Drawing.Point(10, 186);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(75, 23);
            this.btn1.TabIndex = 3;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn2.Location = new System.Drawing.Point(91, 186);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(75, 23);
            this.btn2.TabIndex = 4;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn3.Location = new System.Drawing.Point(172, 186);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(75, 23);
            this.btn3.TabIndex = 5;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn5.Location = new System.Drawing.Point(91, 147);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(75, 23);
            this.btn5.TabIndex = 6;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btnmais
            // 
            this.btnmais.BackColor = System.Drawing.Color.OrangeRed;
            this.btnmais.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnmais.Location = new System.Drawing.Point(254, 186);
            this.btnmais.Name = "btnmais";
            this.btnmais.Size = new System.Drawing.Size(34, 23);
            this.btnmais.TabIndex = 7;
            this.btnmais.Text = "+";
            this.btnmais.UseVisualStyleBackColor = false;
            this.btnmais.Click += new System.EventHandler(this.btnmais_Click);
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn7.Location = new System.Drawing.Point(10, 109);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(75, 23);
            this.btn7.TabIndex = 8;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn4.Location = new System.Drawing.Point(10, 147);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(75, 23);
            this.btn4.TabIndex = 9;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn6.Location = new System.Drawing.Point(173, 147);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(75, 23);
            this.btn6.TabIndex = 10;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btndividir
            // 
            this.btndividir.BackColor = System.Drawing.Color.OrangeRed;
            this.btndividir.Location = new System.Drawing.Point(254, 71);
            this.btndividir.Name = "btndividir";
            this.btndividir.Size = new System.Drawing.Size(34, 23);
            this.btndividir.TabIndex = 12;
            this.btndividir.Text = "/";
            this.btndividir.UseVisualStyleBackColor = false;
            this.btndividir.Click += new System.EventHandler(this.btndividir_Click);
            // 
            // btnmutiplicacao
            // 
            this.btnmutiplicacao.BackColor = System.Drawing.Color.OrangeRed;
            this.btnmutiplicacao.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnmutiplicacao.Location = new System.Drawing.Point(254, 109);
            this.btnmutiplicacao.Name = "btnmutiplicacao";
            this.btnmutiplicacao.Size = new System.Drawing.Size(34, 23);
            this.btnmutiplicacao.TabIndex = 13;
            this.btnmutiplicacao.Text = "X";
            this.btnmutiplicacao.UseVisualStyleBackColor = false;
            this.btnmutiplicacao.Click += new System.EventHandler(this.btnmutiplicacao_Click);
            // 
            // btnmenos
            // 
            this.btnmenos.BackColor = System.Drawing.Color.OrangeRed;
            this.btnmenos.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnmenos.Location = new System.Drawing.Point(254, 147);
            this.btnmenos.Name = "btnmenos";
            this.btnmenos.Size = new System.Drawing.Size(34, 23);
            this.btnmenos.TabIndex = 14;
            this.btnmenos.Text = "-";
            this.btnmenos.UseVisualStyleBackColor = false;
            this.btnmenos.Click += new System.EventHandler(this.btnmenos_Click);
            // 
            // btnporcentagem
            // 
            this.btnporcentagem.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnporcentagem.Location = new System.Drawing.Point(172, 71);
            this.btnporcentagem.Name = "btnporcentagem";
            this.btnporcentagem.Size = new System.Drawing.Size(75, 23);
            this.btnporcentagem.TabIndex = 15;
            this.btnporcentagem.Text = "%";
            this.btnporcentagem.UseVisualStyleBackColor = false;
            this.btnporcentagem.Click += new System.EventHandler(this.btnporcentagem_Click);
            // 
            // btnmaismenos
            // 
            this.btnmaismenos.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnmaismenos.Location = new System.Drawing.Point(91, 71);
            this.btnmaismenos.Name = "btnmaismenos";
            this.btnmaismenos.Size = new System.Drawing.Size(75, 23);
            this.btnmaismenos.TabIndex = 16;
            this.btnmaismenos.Text = "+/-";
            this.btnmaismenos.UseVisualStyleBackColor = false;
            this.btnmaismenos.Click += new System.EventHandler(this.btnmaismenos_Click);
            // 
            // btnAC
            // 
            this.btnAC.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAC.Location = new System.Drawing.Point(10, 71);
            this.btnAC.Name = "btnAC";
            this.btnAC.Size = new System.Drawing.Size(75, 23);
            this.btnAC.TabIndex = 17;
            this.btnAC.Text = "AC";
            this.btnAC.UseVisualStyleBackColor = false;
            this.btnAC.Click += new System.EventHandler(this.btnAC_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn9.Location = new System.Drawing.Point(172, 109);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(75, 23);
            this.btn9.TabIndex = 18;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btn8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn8.Location = new System.Drawing.Point(91, 109);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(75, 23);
            this.btn8.TabIndex = 19;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(12, 28);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(276, 20);
            this.txt1.TabIndex = 20;
            // 
            // Frm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(302, 269);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btnAC);
            this.Controls.Add(this.btnmaismenos);
            this.Controls.Add(this.btnporcentagem);
            this.Controls.Add(this.btnmenos);
            this.Controls.Add(this.btnmutiplicacao);
            this.Controls.Add(this.btndividir);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btnmais);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btnigual);
            this.Controls.Add(this.btnvirgula);
            this.Controls.Add(this.btn0);
            this.Name = "Frm1";
            this.Text = "Calculadora";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btnvirgula;
        private System.Windows.Forms.Button btnigual;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btnmais;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btndividir;
        private System.Windows.Forms.Button btnmutiplicacao;
        private System.Windows.Forms.Button btnmenos;
        private System.Windows.Forms.Button btnporcentagem;
        private System.Windows.Forms.Button btnmaismenos;
        private System.Windows.Forms.Button btnAC;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.TextBox txt1;
    }
}

