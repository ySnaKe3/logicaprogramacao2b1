﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrmDados
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Enviou Formulario");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Limpou o Formulario");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Abriu Formulario");
        }

        private void txtTexto_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            MessageBox.Show("Alterou Texto");
        }
    }
}