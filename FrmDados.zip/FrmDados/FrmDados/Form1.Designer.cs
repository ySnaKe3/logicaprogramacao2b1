﻿namespace FrmDados
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtInteiro = new System.Windows.Forms.MaskedTextBox();
            this.txtTexto = new System.Windows.Forms.MaskedTextBox();
            this.txtDecimal = new System.Windows.Forms.MaskedTextBox();
            this.txtBoleano = new System.Windows.Forms.MaskedTextBox();
            this.lblTexto = new System.Windows.Forms.Label();
            this.lblBoleano = new System.Windows.Forms.Label();
            this.lblDecimal = new System.Windows.Forms.Label();
            this.lblInteiro = new System.Windows.Forms.Label();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtInteiro
            // 
            this.txtInteiro.Location = new System.Drawing.Point(420, 121);
            this.txtInteiro.Name = "txtInteiro";
            this.txtInteiro.Size = new System.Drawing.Size(101, 20);
            this.txtInteiro.TabIndex = 0;
            // 
            // txtTexto
            // 
            this.txtTexto.Location = new System.Drawing.Point(239, 121);
            this.txtTexto.Name = "txtTexto";
            this.txtTexto.Size = new System.Drawing.Size(100, 20);
            this.txtTexto.TabIndex = 1;
            this.txtTexto.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.txtTexto_MaskInputRejected);
            // 
            // txtDecimal
            // 
            this.txtDecimal.Location = new System.Drawing.Point(239, 171);
            this.txtDecimal.Name = "txtDecimal";
            this.txtDecimal.Size = new System.Drawing.Size(101, 20);
            this.txtDecimal.TabIndex = 2;
            // 
            // txtBoleano
            // 
            this.txtBoleano.Location = new System.Drawing.Point(420, 171);
            this.txtBoleano.Name = "txtBoleano";
            this.txtBoleano.Size = new System.Drawing.Size(101, 20);
            this.txtBoleano.TabIndex = 3;
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto.Location = new System.Drawing.Point(252, 93);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(66, 25);
            this.lblTexto.TabIndex = 4;
            this.lblTexto.Text = "Texto";
            // 
            // lblBoleano
            // 
            this.lblBoleano.AutoSize = true;
            this.lblBoleano.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBoleano.Location = new System.Drawing.Point(430, 144);
            this.lblBoleano.Name = "lblBoleano";
            this.lblBoleano.Size = new System.Drawing.Size(91, 25);
            this.lblBoleano.TabIndex = 5;
            this.lblBoleano.Text = "Boleano";
            // 
            // lblDecimal
            // 
            this.lblDecimal.AutoSize = true;
            this.lblDecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDecimal.Location = new System.Drawing.Point(252, 144);
            this.lblDecimal.Name = "lblDecimal";
            this.lblDecimal.Size = new System.Drawing.Size(89, 25);
            this.lblDecimal.TabIndex = 6;
            this.lblDecimal.Text = "Decimal";
            // 
            // lblInteiro
            // 
            this.lblInteiro.AutoSize = true;
            this.lblInteiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInteiro.Location = new System.Drawing.Point(438, 93);
            this.lblInteiro.Name = "lblInteiro";
            this.lblInteiro.Size = new System.Drawing.Size(71, 25);
            this.lblInteiro.TabIndex = 7;
            this.lblInteiro.Text = "Inteiro";
            // 
            // btnEnviar
            // 
            this.btnEnviar.BackColor = System.Drawing.Color.ForestGreen;
            this.btnEnviar.Location = new System.Drawing.Point(421, 269);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(100, 73);
            this.btnEnviar.TabIndex = 8;
            this.btnEnviar.Text = "Enviar";
            this.btnEnviar.UseVisualStyleBackColor = false;
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.Red;
            this.btnLimpar.Location = new System.Drawing.Point(239, 269);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(100, 73);
            this.btnLimpar.TabIndex = 9;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(776, 450);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.lblInteiro);
            this.Controls.Add(this.lblDecimal);
            this.Controls.Add(this.lblBoleano);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.txtBoleano);
            this.Controls.Add(this.txtDecimal);
            this.Controls.Add(this.txtTexto);
            this.Controls.Add(this.txtInteiro);
            this.Name = "Form1";
            this.Text = "Capiturando Dados na tela";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox txtInteiro;
        private System.Windows.Forms.MaskedTextBox txtTexto;
        private System.Windows.Forms.MaskedTextBox txtDecimal;
        private System.Windows.Forms.MaskedTextBox txtBoleano;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Label lblBoleano;
        private System.Windows.Forms.Label lblDecimal;
        private System.Windows.Forms.Label lblInteiro;
        private System.Windows.Forms.Button btnEnviar;
        private System.Windows.Forms.Button btnLimpar;
    }
}

