﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {

        }
    }

        private void btnEnviar_Click(object sender, EventArgs e)
        {

            int varInteiro = int.Parse();
            float varDecimal = float.Parse(txt2.Text);
            float resultado;

        //Soma
        resultado = varInteiro + varDecimal;
        MessageBox.Show("Soma " + resultado);

        //Subtracao
        resultado = varInteiro - varDecimal;
        MessageBox.Show("Subtracao " + resultado);

        //Multiplicacao
        resultado = varInteiro * varDecimal;
        MessageBox.Show("Multiplicacao " + resultado);

        //Divisao
        resultado = varInteiro / varDecimal;
        MessageBox.Show("Divisao " + resultado); 

        }
    }
}
